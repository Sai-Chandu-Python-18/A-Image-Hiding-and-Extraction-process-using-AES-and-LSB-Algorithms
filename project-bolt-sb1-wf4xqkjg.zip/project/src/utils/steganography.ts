// AES encryption utilities using Web Crypto API
export class CryptoUtils {
  static async generateKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
    const encoder = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      encoder.encode(password),
      'PBKDF2',
      false,
      ['deriveKey']
    );

    return crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt,
        iterations: 100000,
        hash: 'SHA-256'
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  static async encrypt(data: ArrayBuffer, password: string): Promise<ArrayBuffer> {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    
    const key = await this.generateKey(password, salt);
    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      data
    );

    // Combine salt + iv + encrypted data
    const result = new Uint8Array(salt.length + iv.length + encrypted.byteLength);
    result.set(salt, 0);
    result.set(iv, salt.length);
    result.set(new Uint8Array(encrypted), salt.length + iv.length);
    
    return result.buffer;
  }

  static async decrypt(encryptedData: ArrayBuffer, password: string): Promise<ArrayBuffer> {
    const data = new Uint8Array(encryptedData);
    const salt = data.slice(0, 16);
    const iv = data.slice(16, 28);
    const encrypted = data.slice(28);

    const key = await this.generateKey(password, salt);
    return crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      encrypted
    );
  }
}

// LSB Steganography utilities
export class LSBSteganography {
  static async embedData(coverImageFile: File, data: ArrayBuffer): Promise<string> {
    return new Promise((resolve, reject) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();

      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx?.drawImage(img, 0, 0);

        const imageData = ctx?.getImageData(0, 0, canvas.width, canvas.height);
        if (!imageData) {
          reject(new Error('Failed to get image data'));
          return;
        }

        const dataBytes = new Uint8Array(data);
        const totalBits = dataBytes.length * 8;
        const headerBits = 32; // 4 bytes for data length
        const requiredPixels = Math.ceil((totalBits + headerBits) / 3);

        if (requiredPixels > imageData.data.length / 4) {
          reject(new Error('Cover image too small to hide the secret data'));
          return;
        }

        // Embed data length in first 4 bytes (32 bits)
        const lengthBytes = new Uint32Array([dataBytes.length]);
        const lengthArray = new Uint8Array(lengthBytes.buffer);
        
        let bitIndex = 0;
        let pixelIndex = 0;

        // Embed length header
        for (let i = 0; i < lengthArray.length; i++) {
          for (let bit = 0; bit < 8; bit++) {
            const bitValue = (lengthArray[i] >> bit) & 1;
            const channelIndex = pixelIndex * 4 + (bitIndex % 3);
            
            // Clear LSB and set new bit
            imageData.data[channelIndex] = (imageData.data[channelIndex] & 0xFE) | bitValue;
            
            bitIndex++;
            if (bitIndex % 3 === 0) pixelIndex++;
          }
        }

        // Embed actual data
        for (let i = 0; i < dataBytes.length; i++) {
          for (let bit = 0; bit < 8; bit++) {
            const bitValue = (dataBytes[i] >> bit) & 1;
            const channelIndex = pixelIndex * 4 + (bitIndex % 3);
            
            imageData.data[channelIndex] = (imageData.data[channelIndex] & 0xFE) | bitValue;
            
            bitIndex++;
            if (bitIndex % 3 === 0) pixelIndex++;
          }
        }

        ctx?.putImageData(imageData, 0, 0);
        resolve(canvas.toDataURL('image/png'));
      };

      img.onerror = () => reject(new Error('Failed to load cover image'));
      img.src = URL.createObjectURL(coverImageFile);
    });
  }

  static async extractData(stegoImageFile: File): Promise<ArrayBuffer> {
    return new Promise((resolve, reject) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();

      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx?.drawImage(img, 0, 0);

        const imageData = ctx?.getImageData(0, 0, canvas.width, canvas.height);
        if (!imageData) {
          reject(new Error('Failed to get image data'));
          return;
        }

        // Extract data length from first 32 bits
        let bitIndex = 0;
        let pixelIndex = 0;
        const lengthBytes = new Uint8Array(4);

        for (let i = 0; i < 4; i++) {
          let byte = 0;
          for (let bit = 0; bit < 8; bit++) {
            const channelIndex = pixelIndex * 4 + (bitIndex % 3);
            const bitValue = imageData.data[channelIndex] & 1;
            byte |= (bitValue << bit);
            
            bitIndex++;
            if (bitIndex % 3 === 0) pixelIndex++;
          }
          lengthBytes[i] = byte;
        }

        const dataLength = new Uint32Array(lengthBytes.buffer)[0];
        
        if (dataLength <= 0 || dataLength > 10 * 1024 * 1024) { // Max 10MB
          reject(new Error('Invalid data length or corrupted stego image'));
          return;
        }

        // Extract actual data
        const extractedData = new Uint8Array(dataLength);
        
        for (let i = 0; i < dataLength; i++) {
          let byte = 0;
          for (let bit = 0; bit < 8; bit++) {
            const channelIndex = pixelIndex * 4 + (bitIndex % 3);
            const bitValue = imageData.data[channelIndex] & 1;
            byte |= (bitValue << bit);
            
            bitIndex++;
            if (bitIndex % 3 === 0) pixelIndex++;
          }
          extractedData[i] = byte;
        }

        resolve(extractedData.buffer);
      };

      img.onerror = () => reject(new Error('Failed to load stego image'));
      img.src = URL.createObjectURL(stegoImageFile);
    });
  }
}

// Main steganography functions
export async function hideImageInCover(
  coverImageFile: File,
  secretImageFile: File,
  password: string,
  onProgress: (progress: number) => void
): Promise<string> {
  onProgress(10);

  // Convert secret image to ArrayBuffer
  const secretImageBuffer = await secretImageFile.arrayBuffer();
  onProgress(25);

  // Encrypt the secret image
  const encryptedData = await CryptoUtils.encrypt(secretImageBuffer, password);
  onProgress(50);

  // Embed encrypted data into cover image
  const stegoImageDataUrl = await LSBSteganography.embedData(coverImageFile, encryptedData);
  onProgress(100);

  return stegoImageDataUrl;
}

export async function extractImageFromCover(
  stegoImageFile: File,
  password: string,
  onProgress: (progress: number) => void
): Promise<string> {
  onProgress(10);

  // Extract encrypted data from stego image
  const encryptedData = await LSBSteganography.extractData(stegoImageFile);
  onProgress(50);

  try {
    // Decrypt the extracted data
    const decryptedData = await CryptoUtils.decrypt(encryptedData, password);
    onProgress(75);

    // Convert decrypted data back to image
    const blob = new Blob([decryptedData]);
    const imageUrl = URL.createObjectURL(blob);
    onProgress(100);

    return imageUrl;
  } catch (error) {
    throw new Error('Failed to decrypt data. Please check your password and ensure the image contains hidden data.');
  }
}