import React, { useState, useRef } from 'react';
import { Upload, Unlock, Download, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { ImageUploader } from './ImageUploader';
import { ProcessingProgress } from './ProcessingProgress';
import { PasswordInput } from './PasswordInput';
import { extractImageFromCover } from '../utils/steganography';

interface ImageData {
  file: File;
  url: string;
}

export function ExtractImagePanel() {
  const [stegoImage, setStegoImage] = useState<ImageData | null>(null);
  const [password, setPassword] = useState('');
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [extractedImage, setExtractedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const downloadRef = useRef<HTMLAnchorElement>(null);

  const handleExtractImage = async () => {
    if (!stegoImage || !password) {
      setError('Please provide both the stego image and password');
      return;
    }

    setError(null);
    setProcessing(true);
    setProgress(0);

    try {
      const result = await extractImageFromCover(
        stegoImage.file,
        password,
        (progress) => setProgress(progress)
      );
      
      setExtractedImage(result);
      setProgress(100);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred during extraction');
    } finally {
      setProcessing(false);
    }
  };

  const handleDownload = () => {
    if (extractedImage && downloadRef.current) {
      downloadRef.current.href = extractedImage;
      downloadRef.current.download = 'extracted-secret-image.png';
      downloadRef.current.click();
    }
  };

  const resetProcess = () => {
    setStegoImage(null);
    setPassword('');
    setExtractedImage(null);
    setError(null);
    setProgress(0);
  };

  return (
    <div className="space-y-8">
      {/* Step Indicator */}
      <div className="flex items-center justify-center space-x-4 mb-8">
        <div className={`flex items-center space-x-2 px-3 py-1 rounded-full text-sm ${
          stegoImage ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-600'
        }`}>
          <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${
            stegoImage ? 'bg-green-500 text-white' : 'bg-slate-400 text-white'
          }`}>1</span>
          Stego Image
        </div>
        <div className="w-8 h-px bg-slate-300" />
        <div className={`flex items-center space-x-2 px-3 py-1 rounded-full text-sm ${
          password ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-600'
        }`}>
          <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${
            password ? 'bg-green-500 text-white' : 'bg-slate-400 text-white'
          }`}>2</span>
          Password
        </div>
        <div className="w-8 h-px bg-slate-300" />
        <div className={`flex items-center space-x-2 px-3 py-1 rounded-full text-sm ${
          extractedImage ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-600'
        }`}>
          <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${
            extractedImage ? 'bg-green-500 text-white' : 'bg-slate-400 text-white'
          }`}>3</span>
          Result
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Section */}
        <div className="space-y-6">
          <ImageUploader
            title="Stego Image"
            description="Upload the image containing hidden data"
            onImageSelect={setStegoImage}
            selectedImage={stegoImage}
            accept="image/*"
            color="purple"
          />

          <PasswordInput
            value={password}
            onChange={setPassword}
            placeholder="Enter decryption password"
          />

          <button
            onClick={handleExtractImage}
            disabled={!stegoImage || !password || processing}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 px-6 rounded-lg font-medium hover:from-purple-700 hover:to-pink-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
          >
            {processing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Extracting...</span>
              </>
            ) : (
              <>
                <Unlock className="w-5 h-5" />
                <span>Extract Image</span>
              </>
            )}
          </button>
        </div>

        {/* Output Section */}
        <div className="space-y-6">
          {processing && (
            <ProcessingProgress
              progress={progress}
              status={
                progress < 25 ? 'Reading stego image...' :
                progress < 75 ? 'Extracting encrypted data...' :
                progress < 100 ? 'Decrypting secret image...' : 'Complete!'
              }
            />
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="text-sm font-medium text-red-800">Extraction Failed</h3>
                <p className="text-sm text-red-700 mt-1">{error}</p>
              </div>
            </div>
          )}

          {extractedImage && (
            <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
              <div className="p-4 border-b border-slate-200 bg-gradient-to-r from-green-50 to-emerald-50">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <h3 className="font-medium text-green-800">Secret Image Extracted</h3>
                </div>
                <p className="text-sm text-green-700 mt-1">
                  The hidden image has been successfully recovered
                </p>
              </div>
              <div className="p-4">
                <img 
                  src={extractedImage} 
                  alt="Extracted secret image" 
                  className="w-full h-64 object-contain bg-slate-50 rounded-lg border"
                />
                <div className="mt-4 flex space-x-3">
                  <button
                    onClick={handleDownload}
                    className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 transition-colors duration-200 flex items-center justify-center space-x-2"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download</span>
                  </button>
                  <button
                    onClick={resetProcess}
                    className="px-4 py-2 border border-slate-300 rounded-lg font-medium text-slate-700 hover:bg-slate-50 transition-colors duration-200"
                  >
                    New Image
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <a ref={downloadRef} className="hidden" />
    </div>
  );
}