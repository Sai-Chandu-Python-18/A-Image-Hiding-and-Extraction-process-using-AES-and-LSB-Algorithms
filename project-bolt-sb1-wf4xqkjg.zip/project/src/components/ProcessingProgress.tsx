import React from 'react';
import { Loader2 } from 'lucide-react';

interface ProcessingProgressProps {
  progress: number;
  status: string;
}

export function ProcessingProgress({ progress, status }: ProcessingProgressProps) {
  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <div className="flex items-center space-x-3 mb-4">
        <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
        <h3 className="font-medium text-slate-900">Processing</h3>
      </div>
      
      <div className="space-y-3">
        <div className="bg-slate-200 rounded-full h-2 overflow-hidden">
          <div 
            className="bg-gradient-to-r from-blue-500 to-purple-500 h-full transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        
        <div className="flex justify-between items-center text-sm">
          <span className="text-slate-600">{status}</span>
          <span className="font-medium text-slate-900">{progress.toFixed(0)}%</span>
        </div>
      </div>
    </div>
  );
}