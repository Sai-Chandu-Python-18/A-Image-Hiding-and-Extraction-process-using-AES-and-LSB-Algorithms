import React, { useRef } from 'react';
import { Upload, X, Image as ImageIcon } from 'lucide-react';

interface ImageData {
  file: File;
  url: string;
}

interface ImageUploaderProps {
  title: string;
  description: string;
  onImageSelect: (image: ImageData | null) => void;
  selectedImage: ImageData | null;
  accept: string;
  color: 'blue' | 'purple';
}

export function ImageUploader({ 
  title, 
  description, 
  onImageSelect, 
  selectedImage, 
  accept,
  color 
}: ImageUploaderProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const url = URL.createObjectURL(file);
      onImageSelect({ file, url });
    }
  };

  const handleDrop = (event: React.DragEvent) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      const url = URL.createObjectURL(file);
      onImageSelect({ file, url });
    }
  };

  const handleDragOver = (event: React.DragEvent) => {
    event.preventDefault();
  };

  const removeImage = () => {
    if (selectedImage) {
      URL.revokeObjectURL(selectedImage.url);
      onImageSelect(null);
    }
  };

  const colorClasses = {
    blue: {
      border: 'border-blue-300 hover:border-blue-400',
      bg: 'bg-blue-50 hover:bg-blue-100',
      text: 'text-blue-600',
      button: 'bg-blue-600 hover:bg-blue-700'
    },
    purple: {
      border: 'border-purple-300 hover:border-purple-400',
      bg: 'bg-purple-50 hover:bg-purple-100',
      text: 'text-purple-600',
      button: 'bg-purple-600 hover:bg-purple-700'
    }
  };

  const colors = colorClasses[color];

  return (
    <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
      <div className="p-4 border-b border-slate-200">
        <h3 className="font-medium text-slate-900">{title}</h3>
        <p className="text-sm text-slate-600 mt-1">{description}</p>
      </div>
      
      <div className="p-4">
        {selectedImage ? (
          <div className="relative">
            <img 
              src={selectedImage.url} 
              alt={title}
              className="w-full h-48 object-contain bg-slate-50 rounded-lg border"
            />
            <button
              onClick={removeImage}
              className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors duration-200"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="mt-2 text-sm text-slate-600">
              <p>{selectedImage.file.name}</p>
              <p>{(selectedImage.file.size / 1024).toFixed(1)} KB</p>
            </div>
          </div>
        ) : (
          <div
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200 cursor-pointer ${colors.border} ${colors.bg}`}
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="space-y-4">
              <div className={`mx-auto w-12 h-12 rounded-full flex items-center justify-center ${colors.bg}`}>
                <Upload className={`w-6 h-6 ${colors.text}`} />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-900">Click to upload or drag and drop</p>
                <p className="text-xs text-slate-500 mt-1">PNG, JPG, GIF up to 10MB</p>
              </div>
            </div>
          </div>
        )}
        
        <input
          ref={fileInputRef}
          type="file"
          accept={accept}
          onChange={handleFileSelect}
          className="hidden"
        />
      </div>
    </div>
  );
}